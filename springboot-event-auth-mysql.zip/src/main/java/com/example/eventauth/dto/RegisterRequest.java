package com.example.eventauth.dto;

public class RegisterRequest {
    public String username;
    public String email;
    public String password;
}