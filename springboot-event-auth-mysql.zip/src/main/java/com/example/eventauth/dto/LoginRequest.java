package com.example.eventauth.dto;

public class LoginRequest {
    public String username;
    public String password;
}