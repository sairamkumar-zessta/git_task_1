package com.example.eventauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventAuthApplication {
    public static void main(String[] args) {
        SpringApplication.run(EventAuthApplication.class, args);
    }
}