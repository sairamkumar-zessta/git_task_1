package com.example.eventauth.controller;

import com.example.eventauth.model.CustomUser;
import com.example.eventauth.repository.UserRepository;
import com.example.eventauth.dto.RegisterRequest;
import com.example.eventauth.dto.LoginRequest;
import com.example.eventauth.security.JwtUtil;
import com.example.eventauth.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpServletRequest;
import java.util.*;

@RestController
@RequestMapping("/api")
public class AuthController {

    @Autowired private UserRepository userRepository;
    @Autowired private EmailService emailService;
    @Autowired private AuthenticationManager authenticationManager;
    @Autowired private JwtUtil jwtUtil;
    @Autowired private PasswordEncoder passwordEncoder;

    private Map<Long, String> tokens = new HashMap<>();

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest req, HttpServletRequest request) {
        CustomUser user = new CustomUser();
        user.setUsername(req.username);
        user.setEmail(req.email);
        user.setPassword(passwordEncoder.encode(req.password));
        user.setActive(false);
        userRepository.save(user);

        String token = UUID.randomUUID().toString();
        tokens.put(user.getId(), token);
        String link = request.getRequestURL().toString().replace("/register", "") +
                      "/activate/" + user.getId() + "/" + token;
        emailService.sendActivationEmail(user.getEmail(), link);

        return ResponseEntity.ok(Map.of("message", "Check your email to activate your account."));
    }

    @GetMapping("/activate/{uid}/{token}")
    public ResponseEntity<?> activate(@PathVariable Long uid, @PathVariable String token) {
        if (!tokens.containsKey(uid) || !tokens.get(uid).equals(token))
            return ResponseEntity.badRequest().body(Map.of("error", "Invalid or expired token"));

        CustomUser user = userRepository.findById(uid).orElseThrow();
        user.setActive(true);
        userRepository.save(user);
        tokens.remove(uid);
        return ResponseEntity.ok(Map.of("message", "Account activated successfully!"));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest req) {
        Authentication auth = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(req.username, req.password));
        String token = jwtUtil.generateToken((CustomUser) auth.getPrincipal());
        return ResponseEntity.ok(Map.of("token", token));
    }

    @GetMapping("/user")
    public ResponseEntity<?> getUser(Authentication authentication) {
        CustomUser user = (CustomUser) authentication.getPrincipal();
        return ResponseEntity.ok(Map.of(
            "id", user.getId(),
            "username", user.getUsername(),
            "email", user.getEmail(),
            "is_active", user.isEnabled(),
            "date_joined", user.getDateJoined()
        ));
    }
}